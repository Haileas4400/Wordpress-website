<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress');

/** MySQL database username */
define('DB_USER', 'Hailea');

/** MySQL database password */
define('DB_PASSWORD', 'OLIVER4400');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         ')|/^G(r!vHH+f}Y gKy[]{j,;3f1Dol;C.b{;jh^X1slL;o;`K$ }wyN(k0D5+YJ');
define('SECURE_AUTH_KEY',  'R+)`{R8`ev0wR:7AvFpg+9|5JK<=[ss63E:l*]L#JJMw/{;!nYfao|9-g4<`+Y<v');
define('LOGGED_IN_KEY',    ',0/pHxjS`_S*x.mMX-}&.!zLagcQF`7bHR;~11/j,,)=WV=ML#;MRX%{B=Nx[wIO');
define('NONCE_KEY',        'X6?7eZQF~%>)Q%QXy*c2!6^`8n#>,5WrT5n+i]b`|.ogSA[4rE_p]B/1Vc;@-gqB');
define('AUTH_SALT',        'KK/`@wd34x|9U0mac3(ly+^ID!f]&Va0<3T@t[463ZLdiMpMb=R?@t!=PfyBor/7');
define('SECURE_AUTH_SALT', 'r5^r1Sjei@x|/i,(;g!ZJ0U)eH[P1=h$j/2zw7oi!V5(d&uXxPjd%O/+.crXeLy!');
define('LOGGED_IN_SALT',   'Ms=yzO[/f,D!6h1l7fZ:]M(4ukOCGoMZNf65&D(Z6f<Qb02VYEy+,;=T9Q,uF[2-');
define('NONCE_SALT',       '5%iEdp%>>UfNOIo:T%&`S:kpe_PE/emY11kjE#`^th87 =OcR48JdOGu}!peYrSa');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
